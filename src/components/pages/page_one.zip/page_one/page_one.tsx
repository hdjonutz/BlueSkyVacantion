import * as React from 'react';
import 'reflect-metadata';
import {CounterService} from '../../../services/CounterService';
import { resolve } from 'inversify-react';
import {Logger} from '../../../util/logger';
import ReactTooltip from 'react-tooltip';
import {AuthenticationService} from '../../../services/authentication_service';
import {LocalConfigurationService} from "../../../services/local_configuration_service";
import {ApiService} from "../../../services/api_service";
import {VersionService} from "../../../services/version_service";
import {HttpClient} from "../../../services/http_client";
import {SnackbarService} from "../../../services/snackbar_service";
import classNames from 'classnames';
import style from './page_one.less';



export default class Page_one extends React.PureComponent<{}, {selected: number}> {

    @resolve(CounterService)        private counterService: CounterService;
    @resolve(AuthenticationService) private authenticationService: AuthenticationService;

    @resolve(ApiService)                private ApiService: ApiService;
    @resolve(VersionService)            private VersionService: VersionService;
    @resolve(HttpClient)                private HttpClient: HttpClient;
    @resolve(SnackbarService)           private SnackbarService: SnackbarService;
    @resolve(LocalConfigurationService) private LocalConfigurationService: LocalConfigurationService;


    // @lazyInject("counterService") private readonly counterService: ICounterService<string>;

    constructor(props: any) {
        super(props);
        this.state = {
            selected: 0,
        };
    }

    componentDidMount() {
        // console.log(this);

        this.authenticationService.login('daniel', 'pass')
            .subscribe((res: any) => {
                // debugger;
                console.log(res);
            });
    }

    componentDidUpdate(prevProps, prevState) {
        // logger.info('Example of logger');
        // this._counterService.getData().subscribe((res) => {
        //     console.log("RESULT: ", res);
        // });
    }

    onClickEl(nr: number): void {        
        this.setState({selected: nr}, 
            () => {
                if (this.props.onChange) {
                    this.props.onChange(this.state.selected);
                }
            });        
    }
    public render() {
        return (
            <React.Fragment>
                <div style={{display: 'flex', flex: 1}}>
                    <div className={classNames(style.switchToggle, style.switchCandy)}>
                        <input id={'1'} name={"state-d"} type={'radio'} value={'1'} />
                        <label htmlFor={"1"} >1</label>

                        <input id={'na'} name={"state-d"} type={'radio'} value={'na'} checked={true} />
                        <label htmlFor={'na'} >na</label>

                        <input id={'2'} name={"state-d"} type={'radio'} value={'2'}/>
                        <label htmlFor={'2'} >2</label>
                        <a></a>
                    </div>

                    ......................................................<br/>
                    <div className={classNames(style.switch)}>
                        <div className={classNames(style.el, this.state.selected === 1 ? style.selected : '')} onClick={(e) => this.onClickEl(1)}>1</div>
                        <div className={classNames(style.el, this.state.selected === 0 ? style.selected : '')} onClick={(e) => this.onClickEl(0)}>&nbsp;</div>
                        <div className={classNames(style.el, this.state.selected === 2 ? style.selected : '')} onClick={(e) => this.onClickEl(2)}>2</div>
                    </div>
                    {/*
                    <p data-tip="hello world here is a tooltip">Tooltip</p>
                    <ReactTooltip /> */}
                </div>
            </React.Fragment>
        );
    }
};
